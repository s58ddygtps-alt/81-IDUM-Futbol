# 81 IDUM Futbol

Ishga tushirish:
1. `index.html` boshidagi `firebaseConfig` ga apiKey va appId ni qo'ying.
2. Firebase: Authentication > Email/Password ni yoqing.
3. `database.rules.json` ichidagini Database > Rules ga qo'yib Publish qiling.
4. Admin foydalanuvchi yarating va `admins/<UID>` = true yozing.
5. GitHub: Settings > Pages > Branch: main / root.
